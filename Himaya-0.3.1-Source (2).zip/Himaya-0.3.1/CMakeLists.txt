cmake_minimum_required(VERSION 3.24)
project(Himaya VERSION 0.3.1 LANGUAGES C CXX)

if(NOT WIN32)
  message(FATAL_ERROR "Himaya currently targets Windows only.")
endif()

set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)

# Fetch the official, version-pinned SQLite amalgamation at configure time.
# SQLite is public domain. HTTPS and a fixed release URL avoid floating dependencies.
set(SQLITE_VERSION "3540100")
set(SQLITE_ROOT "${CMAKE_BINARY_DIR}/_deps/sqlite")
set(SQLITE_ARCHIVE "${CMAKE_BINARY_DIR}/_deps/sqlite-amalgamation-${SQLITE_VERSION}.zip")
set(SQLITE_SOURCE_DIR "${SQLITE_ROOT}/sqlite-amalgamation-${SQLITE_VERSION}")

if(NOT EXISTS "${SQLITE_SOURCE_DIR}/sqlite3.c")
  file(MAKE_DIRECTORY "${CMAKE_BINARY_DIR}/_deps")
  file(DOWNLOAD
    "https://www.sqlite.org/2026/sqlite-amalgamation-${SQLITE_VERSION}.zip"
    "${SQLITE_ARCHIVE}"
    TLS_VERIFY ON
    SHOW_PROGRESS
    STATUS SQLITE_DOWNLOAD_STATUS
  )
  list(GET SQLITE_DOWNLOAD_STATUS 0 SQLITE_DOWNLOAD_CODE)
  if(NOT SQLITE_DOWNLOAD_CODE EQUAL 0)
    list(GET SQLITE_DOWNLOAD_STATUS 1 SQLITE_DOWNLOAD_MESSAGE)
    message(FATAL_ERROR "Could not download SQLite: ${SQLITE_DOWNLOAD_MESSAGE}")
  endif()
  file(ARCHIVE_EXTRACT INPUT "${SQLITE_ARCHIVE}" DESTINATION "${SQLITE_ROOT}")
endif()

add_executable(Himaya WIN32
  App/main.cpp
  App/MainWindow.cpp
  Core/ConfigStore.cpp
  Core/WebsiteBlocker.cpp
  "${SQLITE_SOURCE_DIR}/sqlite3.c"
)

target_include_directories(Himaya PRIVATE
  "${CMAKE_CURRENT_SOURCE_DIR}"
  "${SQLITE_SOURCE_DIR}"
)
target_compile_definitions(Himaya PRIVATE
  UNICODE _UNICODE WIN32_LEAN_AND_MEAN NOMINMAX
  SQLITE_THREADSAFE=1 SQLITE_OMIT_LOAD_EXTENSION
)
target_link_libraries(Himaya PRIVATE comctl32 shell32 shlwapi ole32 winhttp normaliz)

if(MSVC)
  target_compile_options(Himaya PRIVATE /W4 /permissive- /utf-8)
  set_source_files_properties("${SQLITE_SOURCE_DIR}/sqlite3.c" PROPERTIES COMPILE_OPTIONS "/w")
endif()

set_target_properties(Himaya PROPERTIES
  RUNTIME_OUTPUT_DIRECTORY "${CMAKE_BINARY_DIR}/bin"
  RUNTIME_OUTPUT_DIRECTORY_RELEASE "${CMAKE_BINARY_DIR}/bin"
)
